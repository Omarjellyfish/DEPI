// Define functions in global scope
window.onload;
let count = 0;

function increase() {
  count += 1;
  updateBits();
}

function decrease() {
  count -= 1;
  updateBits();
}

function reset() {
  count = 0;
  updateBits();
}
// i already had the code for it in python ready so i reused it
function convertToBinary(num) {
  let bits = new Array(4).fill(0); // Initialize a 4-bit array filled with zeros

  if (num === 0) {
    return bits;
  }

  let i = 3; // Start index for 4-bit representation (0-indexed)
  while (num !== 0 && i >= 0) {
    bits[i] = num % 2; // Store the remainder (either 0 or 1)
    num = Math.floor(num / 2); // Update num by integer division by 2
    i--; // Move to the next bit position
  }

  return bits;
}

function updateBits() {
  let binaryForm = convertToBinary(count);

  document.getElementById("bit-3").innerText = binaryForm[0];
  document.getElementById("bit-2").innerText = binaryForm[1];
  document.getElementById("bit-1").innerText = binaryForm[2];
  document.getElementById("bit-0").innerText = binaryForm[3];
  if (count == 16) {
    document.getElementById("count").innerText = count;
    count = -1;
  } else {
    document.getElementById("count").innerText = count;
  }
}
window.onload = function () {
  // Wait for the DOM content to fully load
  window.addEventListener("DOMContentLoaded", function () {
    // Event listeners for buttons
    document.getElementById("increase").addEventListener("click", increase);
    document.getElementById("decrease").addEventListener("click", decrease);
    document.getElementById("reset").addEventListener("click", reset);

    // Initial update on page load
    updateBits();
  });
};
