var inputs = document.querySelectorAll("input")[0];
var btn = document.getElementsByClassName("buttonC")[0];
var r = new RegExp(/^\d+$/);
console.log(btn);

btn.addEventListener("click", function () {
  if (r.test(inputs.value)) {
    console.log(inputs.value);
  } else {
    alert("enter Valid input type ie. pos integers");
  }
});
// dont forget to use window.onload
// or link the script at the end
